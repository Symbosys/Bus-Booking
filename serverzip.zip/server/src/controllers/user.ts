import { Request, Response } from "express"
import userSchema from "../zod/User"

export async function usersignup (req: Request,res: Response){
   const {number} =req.body

   const validData = userSchema.parse({number})
}