import express from "express"

const app = express();

app.get("/", function(req,res){
    res.json({
        message:"hello world"
    })
})
app.post("create")


app.listen(4000,function(){
    console.log("server started")
})